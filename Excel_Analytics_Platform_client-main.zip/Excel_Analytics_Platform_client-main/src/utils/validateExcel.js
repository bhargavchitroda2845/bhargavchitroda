export const validateExcel = (file) => {
    // Placeholder for Excel file validation logic
    return file && file.name.endsWith('.xlsx');
}; 