export default function Chart3D({ data }) {
    return (
        <div className="h-72 flex items-center justify-center">
            {/* Three.js chart will render here */}
            <span className="text-muted-foreground">3D Chart Placeholder</span>
        </div>
    );
} 