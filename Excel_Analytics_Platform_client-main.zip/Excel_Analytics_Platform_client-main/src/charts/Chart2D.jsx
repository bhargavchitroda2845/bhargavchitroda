export default function Chart2D({ data, options }) {
    return (
        <div className="h-72 flex items-center justify-center">
            {/* Chart.js chart will render here */}
            <span className="text-muted-foreground">2D Chart Placeholder</span>
        </div>
    );
} 